
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/app.js
import { readFile } from "node:fs/promises";

// netlify/functions/_auth.js
import crypto from "node:crypto";
function sign(data) {
  const secret = process.env.TICKET_SECRET;
  if (!secret) throw new Error("\u043D\u0435 \u0437\u0430\u0434\u0430\u043D TICKET_SECRET");
  return crypto.createHmac("sha256", secret).update(data).digest("base64url");
}
function readTicket(ticket) {
  const t = String(ticket ?? "");
  if (!t.includes(".")) return null;
  const [body, sig] = t.split(".");
  let good;
  try {
    good = Buffer.from(sign(body));
  } catch {
    return null;
  }
  const given = Buffer.from(String(sig));
  if (good.length !== given.length || !crypto.timingSafeEqual(good, given)) return null;
  try {
    const who = JSON.parse(Buffer.from(body, "base64url").toString());
    return who.exp > Date.now() ? who : null;
  } catch {
    return null;
  }
}
var \u0418\u041C\u042F_COOKIE = "propusk";
function ticketFromRequest(request) {
  const raw = request.headers.get("cookie") || "";
  for (const part of raw.split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === \u0418\u041C\u042F_COOKIE || k === "\u043F\u0440\u043E\u043F\u0443\u0441\u043A") {
      const t = readTicket(decodeURIComponent(v.join("=")));
      if (t) return t;
    }
  }
  return null;
}

// netlify/functions/app.js
var app_default = async (request) => {
  if (!ticketFromRequest(request)) {
    return new Response(null, { status: 302, headers: { location: "/" } });
  }
  try {
    const html = await readFile(new URL("../../private/app.html", import.meta.url), "utf-8");
    return new Response(html, {
      status: 200,
      headers: {
        "content-type": "text/html; charset=utf-8",
        "cache-control": "private, no-store"
      }
    });
  } catch {
    return new Response("\u0414\u0430\u0448\u0431\u043E\u0440\u0434 \u0435\u0449\u0451 \u043D\u0435 \u0441\u043E\u0431\u0440\u0430\u043D.", {
      status: 503,
      headers: { "content-type": "text/plain; charset=utf-8" }
    });
  }
};
export {
  app_default as default
};
