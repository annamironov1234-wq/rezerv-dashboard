
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/stamp.js
import { readFile } from "node:fs/promises";

// netlify/functions/_auth.js
import crypto from "node:crypto";
function sign(data) {
  const secret = process.env.TICKET_SECRET;
  if (!secret) throw new Error("\u043D\u0435 \u0437\u0430\u0434\u0430\u043D TICKET_SECRET");
  return crypto.createHmac("sha256", secret).update(data).digest("base64url");
}
function readTicket(ticket) {
  const t = String(ticket ?? "");
  if (!t.includes(".")) return null;
  const [body, sig] = t.split(".");
  let good;
  try {
    good = Buffer.from(sign(body));
  } catch {
    return null;
  }
  const given = Buffer.from(String(sig));
  if (good.length !== given.length || !crypto.timingSafeEqual(good, given)) return null;
  try {
    const who = JSON.parse(Buffer.from(body, "base64url").toString());
    return who.exp > Date.now() ? who : null;
  } catch {
    return null;
  }
}
var \u0418\u041C\u042F_COOKIE = "propusk";
function ticketFromRequest(request) {
  const raw = request.headers.get("cookie") || "";
  for (const part of raw.split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === \u0418\u041C\u042F_COOKIE || k === "\u043F\u0440\u043E\u043F\u0443\u0441\u043A") {
      const t = readTicket(decodeURIComponent(v.join("=")));
      if (t) return t;
    }
  }
  return null;
}
var \u043D\u0435\u043B\u044C\u0437\u044F = () => new Response(JSON.stringify({ \u043E\u0448\u0438\u0431\u043A\u0430: "\u043D\u0443\u0436\u0435\u043D \u0432\u0445\u043E\u0434" }), {
  status: 401,
  headers: { "content-type": "application/json; charset=utf-8" }
});

// netlify/functions/stamp.js
var stamp_default = async (request) => {
  if (!ticketFromRequest(request)) return \u043D\u0435\u043B\u044C\u0437\u044F();
  try {
    const \u0442\u0435\u043A\u0441\u0442 = await readFile(new URL("../../private/stamp.txt", import.meta.url), "utf-8");
    return new Response(\u0442\u0435\u043A\u0441\u0442, {
      status: 200,
      headers: {
        "content-type": "text/plain; charset=utf-8",
        "cache-control": "private, no-store"
      }
    });
  } catch {
    return new Response("", { status: 404 });
  }
};
export {
  stamp_default as default
};
