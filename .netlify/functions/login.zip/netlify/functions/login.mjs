
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_auth.js
import crypto from "node:crypto";
function checkPassword(plain, stored) {
  const parts = String(stored ?? "").split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  let key;
  try {
    key = crypto.scryptSync(String(plain).normalize("NFKC"), parts[1], 32);
  } catch {
    return false;
  }
  const \u0431\u044B\u043B\u043E = Buffer.from(parts[2], "hex");
  return key.length === \u0431\u044B\u043B\u043E.length && crypto.timingSafeEqual(key, \u0431\u044B\u043B\u043E);
}
function sign(data) {
  const secret = process.env.TICKET_SECRET;
  if (!secret) throw new Error("\u043D\u0435 \u0437\u0430\u0434\u0430\u043D TICKET_SECRET");
  return crypto.createHmac("sha256", secret).update(data).digest("base64url");
}
function makeTicket(days = 30) {
  const body = Buffer.from(JSON.stringify({
    exp: Date.now() + days * 864e5
  })).toString("base64url");
  return `${body}.${sign(body)}`;
}

// netlify/functions/login.js
var \u043F\u0430\u0443\u0437\u0430 = (\u043C\u0441) => new Promise((r) => setTimeout(r, \u043C\u0441));
var login_default = async (request) => {
  if (request.method !== "POST") {
    return new Response("\u0442\u043E\u043B\u044C\u043A\u043E POST", { status: 405 });
  }
  const \u0445\u044D\u0448 = process.env.PASSWORD_HASH;
  if (!\u0445\u044D\u0448) {
    return new Response(
      JSON.stringify({ \u043E\u0448\u0438\u0431\u043A\u0430: "\u043F\u0430\u0440\u043E\u043B\u044C \u0435\u0449\u0451 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D, \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u0435 setup/\u0443\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C-\u043F\u0430\u0440\u043E\u043B\u044C.sh" }),
      { status: 500, headers: { "content-type": "application/json; charset=utf-8" } }
    );
  }
  let \u043F\u0430\u0440\u043E\u043B\u044C = "";
  try {
    \u043F\u0430\u0440\u043E\u043B\u044C = (await request.json()).\u043F\u0430\u0440\u043E\u043B\u044C ?? "";
  } catch {
    \u043F\u0430\u0440\u043E\u043B\u044C = "";
  }
  if (!checkPassword(\u043F\u0430\u0440\u043E\u043B\u044C, \u0445\u044D\u0448)) {
    await \u043F\u0430\u0443\u0437\u0430(1200);
    return new Response(JSON.stringify({ \u043E\u0448\u0438\u0431\u043A\u0430: "\u043D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043F\u0430\u0440\u043E\u043B\u044C" }), {
      status: 401,
      headers: { "content-type": "application/json; charset=utf-8" }
    });
  }
  const \u043F\u0440\u043E\u043F\u0443\u0441\u043A = makeTicket(30);
  return new Response(JSON.stringify({ \u043E\u043A: true }), {
    status: 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      // Имя строго латиницей. По стандарту (RFC 6265) имя cookie - это токен
      // из ASCII, и «пропуск» кириллицей браузер молча выбрасывает: пароль
      // принимается, пропуск не сохраняется, человека возвращает на форму,
      // и выглядит это как «пароль не подошёл». Проверено 17.08.2026.
      //
      // HttpOnly: пропуск не виден скриптам на странице
      // SameSite=Lax: не уедет на чужой сайт
      "set-cookie": `propusk=${encodeURIComponent(\u043F\u0440\u043E\u043F\u0443\u0441\u043A)}; Path=/; Max-Age=${30 * 86400}; HttpOnly; Secure; SameSite=Lax`
    }
  });
};
export {
  login_default as default
};
