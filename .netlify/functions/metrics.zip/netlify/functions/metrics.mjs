
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/metrics.js
import { readFile } from "node:fs/promises";

// netlify/functions/_auth.js
import crypto from "node:crypto";
function sign(data) {
  const secret = process.env.TICKET_SECRET;
  if (!secret) throw new Error("\u043D\u0435 \u0437\u0430\u0434\u0430\u043D TICKET_SECRET");
  return crypto.createHmac("sha256", secret).update(data).digest("base64url");
}
function readTicket(ticket) {
  const t = String(ticket ?? "");
  if (!t.includes(".")) return null;
  const [body, sig] = t.split(".");
  let good;
  try {
    good = Buffer.from(sign(body));
  } catch {
    return null;
  }
  const given = Buffer.from(String(sig));
  if (good.length !== given.length || !crypto.timingSafeEqual(good, given)) return null;
  try {
    const who = JSON.parse(Buffer.from(body, "base64url").toString());
    return who.exp > Date.now() ? who : null;
  } catch {
    return null;
  }
}
var \u0418\u041C\u042F_COOKIE = "propusk";
function ticketFromRequest(request) {
  const raw = request.headers.get("cookie") || "";
  for (const part of raw.split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === \u0418\u041C\u042F_COOKIE || k === "\u043F\u0440\u043E\u043F\u0443\u0441\u043A") {
      const t = readTicket(decodeURIComponent(v.join("=")));
      if (t) return t;
    }
  }
  return null;
}
function \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u044B\u0439\u041A\u043B\u044E\u0447\u0412\u0435\u0440\u0435\u043D(request) {
  const \u0434\u0430\u043D = request.headers.get("x-build-token") || "";
  const \u043D\u0443\u0436\u0435\u043D = process.env.BUILD_TOKEN || "";
  if (!\u043D\u0443\u0436\u0435\u043D || !\u0434\u0430\u043D) return false;
  const a = Buffer.from(String(\u0434\u0430\u043D));
  const b = Buffer.from(String(\u043D\u0443\u0436\u0435\u043D));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
var \u043D\u0435\u043B\u044C\u0437\u044F = () => new Response(JSON.stringify({ \u043E\u0448\u0438\u0431\u043A\u0430: "\u043D\u0443\u0436\u0435\u043D \u0432\u0445\u043E\u0434" }), {
  status: 401,
  headers: { "content-type": "application/json; charset=utf-8" }
});

// netlify/functions/metrics.js
var metrics_default = async (request) => {
  const \u0441\u0432\u043E\u0439 = ticketFromRequest(request) || \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u044B\u0439\u041A\u043B\u044E\u0447\u0412\u0435\u0440\u0435\u043D(request);
  if (!\u0441\u0432\u043E\u0439) return \u043D\u0435\u043B\u044C\u0437\u044F();
  try {
    const \u0442\u0435\u043A\u0441\u0442 = await readFile(new URL("../../private/metrics.json", import.meta.url), "utf-8");
    return new Response(\u0442\u0435\u043A\u0441\u0442, {
      status: 200,
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "private, no-store"
      }
    });
  } catch {
    return new Response(JSON.stringify({ \u043E\u0448\u0438\u0431\u043A\u0430: "\u0441\u043B\u0435\u043F\u043A\u0430 \u0435\u0449\u0451 \u043D\u0435\u0442" }), {
      status: 404,
      headers: { "content-type": "application/json; charset=utf-8" }
    });
  }
};
export {
  metrics_default as default
};
