var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_auth.js
var auth_exports = {};
__export(auth_exports, {
  checkPassword: () => checkPassword,
  hashPassword: () => hashPassword,
  makeTicket: () => makeTicket,
  readTicket: () => readTicket,
  ticketFromRequest: () => ticketFromRequest,
  \u0418\u041C\u042F_COOKIE: () => \u0418\u041C\u042F_COOKIE,
  \u043D\u0435\u043B\u044C\u0437\u044F: () => \u043D\u0435\u043B\u044C\u0437\u044F,
  \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u044B\u0439\u041A\u043B\u044E\u0447\u0412\u0435\u0440\u0435\u043D: () => \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u044B\u0439\u041A\u043B\u044E\u0447\u0412\u0435\u0440\u0435\u043D
});
module.exports = __toCommonJS(auth_exports);
var import_node_crypto = __toESM(require("crypto"), 1);
function hashPassword(plain) {
  const salt = import_node_crypto.default.randomBytes(16).toString("hex");
  const key = import_node_crypto.default.scryptSync(String(plain).normalize("NFKC"), salt, 32).toString("hex");
  return `scrypt$${salt}$${key}`;
}
function checkPassword(plain, stored) {
  const parts = String(stored ?? "").split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  let key;
  try {
    key = import_node_crypto.default.scryptSync(String(plain).normalize("NFKC"), parts[1], 32);
  } catch {
    return false;
  }
  const \u0431\u044B\u043B\u043E = Buffer.from(parts[2], "hex");
  return key.length === \u0431\u044B\u043B\u043E.length && import_node_crypto.default.timingSafeEqual(key, \u0431\u044B\u043B\u043E);
}
function sign(data) {
  const secret = process.env.TICKET_SECRET;
  if (!secret) throw new Error("\u043D\u0435 \u0437\u0430\u0434\u0430\u043D TICKET_SECRET");
  return import_node_crypto.default.createHmac("sha256", secret).update(data).digest("base64url");
}
function makeTicket(days = 30) {
  const body = Buffer.from(JSON.stringify({
    exp: Date.now() + days * 864e5
  })).toString("base64url");
  return `${body}.${sign(body)}`;
}
function readTicket(ticket) {
  const t = String(ticket ?? "");
  if (!t.includes(".")) return null;
  const [body, sig] = t.split(".");
  let good;
  try {
    good = Buffer.from(sign(body));
  } catch {
    return null;
  }
  const given = Buffer.from(String(sig));
  if (good.length !== given.length || !import_node_crypto.default.timingSafeEqual(good, given)) return null;
  try {
    const who = JSON.parse(Buffer.from(body, "base64url").toString());
    return who.exp > Date.now() ? who : null;
  } catch {
    return null;
  }
}
var \u0418\u041C\u042F_COOKIE = "propusk";
function ticketFromRequest(request) {
  const raw = request.headers.get("cookie") || "";
  for (const part of raw.split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === \u0418\u041C\u042F_COOKIE || k === "\u043F\u0440\u043E\u043F\u0443\u0441\u043A") {
      const t = readTicket(decodeURIComponent(v.join("=")));
      if (t) return t;
    }
  }
  return null;
}
function \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u044B\u0439\u041A\u043B\u044E\u0447\u0412\u0435\u0440\u0435\u043D(request) {
  const \u0434\u0430\u043D = request.headers.get("x-build-token") || "";
  const \u043D\u0443\u0436\u0435\u043D = process.env.BUILD_TOKEN || "";
  if (!\u043D\u0443\u0436\u0435\u043D || !\u0434\u0430\u043D) return false;
  const a = Buffer.from(String(\u0434\u0430\u043D));
  const b = Buffer.from(String(\u043D\u0443\u0436\u0435\u043D));
  return a.length === b.length && import_node_crypto.default.timingSafeEqual(a, b);
}
var \u043D\u0435\u043B\u044C\u0437\u044F = () => new Response(JSON.stringify({ \u043E\u0448\u0438\u0431\u043A\u0430: "\u043D\u0443\u0436\u0435\u043D \u0432\u0445\u043E\u0434" }), {
  status: 401,
  headers: { "content-type": "application/json; charset=utf-8" }
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  checkPassword,
  hashPassword,
  makeTicket,
  readTicket,
  ticketFromRequest,
  \u0418\u041C\u042F_COOKIE,
  \u043D\u0435\u043B\u044C\u0437\u044F,
  \u0441\u043B\u0443\u0436\u0435\u0431\u043D\u044B\u0439\u041A\u043B\u044E\u0447\u0412\u0435\u0440\u0435\u043D
});
